package models;

public class Student {

    private int rno;
    private String fullname;
    private String username;
    private String password;
    private String className;

    public Student(int rno, String fullname, String username, String password, String className) {
        this.rno = rno;
        this.fullname = fullname;
        this.username = username;
        this.password = password;
        this.className = className;
    }

    public Student(String fullname, String username, String password, String className) {
        this.fullname = fullname;
        this.username = username;
        this.password = password;
        this.className = className;
    }

    public int getRno() {
        return rno;
    }

    public void setRno(int rno) {
        this.rno = rno;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    @Override
    public String toString() {
        return "Student{" + "rno=" + rno + ", fullname=" + fullname + ", username=" + username + ", password=" + password + ", className=" + className + '}';
    }

}
