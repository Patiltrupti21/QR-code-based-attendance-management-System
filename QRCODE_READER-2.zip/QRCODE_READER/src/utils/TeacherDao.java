package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.Teacher;

public class TeacherDao {
    
    private Connection con = null;
    
    public TeacherDao() {
        con = Dbcon.createConnection();
    }
    
    public List<Teacher> getTeachers(){
        List<Teacher> list = new ArrayList<>();
        try {
            PreparedStatement pstmt = con.prepareStatement("select * from teacher");
            ResultSet rst = pstmt.executeQuery();
            while(rst.next()) {
                Teacher teacher = new Teacher(
                    rst.getInt("id"),
                    rst.getString("fullname"),
                    rst.getString("username"),
                    rst.getString("password"),
                    rst.getString("subject")
                );
                list.add(teacher);
            }
        } catch (SQLException e) {
            System.out.println("Database Error3!");
        }  
        return list;
    }
    
    public String registerTeacher(Teacher newTeacher){
        String result="";
        try {
            PreparedStatement pstmt = con.prepareStatement("insert into teacher(fullname,username,password,subject) values(?,?,?,?)");
            pstmt.setString(1, newTeacher.getFullname());
            pstmt.setString(2, newTeacher.getUsername());
            pstmt.setString(3, newTeacher.getPassword());
            pstmt.setString(4, newTeacher.getSubject());
            if( pstmt.executeUpdate()==1 ) {
                result = "Teacher registered!";
            } else {
                result = "Teacher with same username exists!";
            }
        } catch (SQLException e) {
            result = "Teacher with same username exists!";
        }
        return result;
    }
    
    public String updateTeacher(Teacher newTeacher){
        String result="";
        try {
            PreparedStatement pstmt = con.prepareStatement("update teacher set fullname=?,password=?,subject=? where id=?");
            pstmt.setString(1, newTeacher.getFullname());
            pstmt.setString(2, newTeacher.getPassword());
            pstmt.setString(3, newTeacher.getSubject());
            pstmt.setLong(4, newTeacher.getId());
            if( pstmt.executeUpdate()==1 ) {
                result = "Teacher updated!";
            } else {
                result = "Failed to update teacher!";
            }
        } catch (SQLException e) {
            result = "Database Error";
        }
        return result;
    }

    public String deleteTeacher(int id) {
        String result = "";
        try {
            PreparedStatement pstmt = con.prepareStatement("delete from teacher where id=?");
            pstmt.setLong(1, id);
            if( pstmt.executeUpdate()==1 ) {
                result = "Teacher deleted!";
            } else {
                result = "Failed to delete teacher!";
            }
        } catch (SQLException e) {
            result = "Database Error";
        }
        return result;
    }
}
