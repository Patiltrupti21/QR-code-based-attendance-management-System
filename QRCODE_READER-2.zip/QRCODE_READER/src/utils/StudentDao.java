package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Student;

public class StudentDao {
    
    private Connection con = null;
    
    public StudentDao() {
        con = Dbcon.createConnection();
    }
    
    public List<Student> getStudents(){
        List<Student> list = new ArrayList<>();
        try {
            PreparedStatement pstmt = con.prepareStatement("select * from student");
            ResultSet rst = pstmt.executeQuery();
            while(rst.next()) {
                Student student = new Student(
                    rst.getInt("rno"),
                    rst.getString("fullname"),
                    rst.getString("username"),
                    rst.getString("password"),
                    rst.getString("class")
                );
                list.add(student);
            }
        } catch (SQLException e) {
            System.out.println("Database Error3!");
        }  
        return list;
    }
    
    public String registerStudent(Student newStudent){
        String result="";
        try {
            PreparedStatement pstmt = con.prepareStatement("insert into student(fullname,username,password,class) values(?,?,?,?)");
            pstmt.setString(1, newStudent.getFullname());
            pstmt.setString(2, newStudent.getUsername());
            pstmt.setString(3, newStudent.getPassword());
            pstmt.setString(4, newStudent.getClassName());
            if( pstmt.executeUpdate()==1 ) {
                result = "Student registered!";
            } else {
                result = "Student with same username exists!";
            }
        } catch (SQLException e) {
            result = "Student with same username exists!";
        }
        return result;
    }
    
    public String updateStudent(Student newStudent){
        String result="";
        try {
            PreparedStatement pstmt = con.prepareStatement("update student set fullname=?,password=?,class=? where rno=?");
            pstmt.setString(1, newStudent.getFullname());
            pstmt.setString(2, newStudent.getPassword());
            pstmt.setString(3, newStudent.getClassName());
            pstmt.setInt(4, newStudent.getRno());
            if( pstmt.executeUpdate()==1 ) {
                result = "Student updated!";
            } else {
                result = "Failed to update student!";
            }
        } catch (SQLException e) {
            result = "Database Error";
        }
        return result;
    }

    public String deleteStudent(int rno) {
        String result = "";
        try {
            PreparedStatement pstmt = con.prepareStatement("delete from teacher where rno=?");
            pstmt.setInt(1, rno);
            if( pstmt.executeUpdate()==1 ) {
                result = "Student deleted!";
            } else {
                result = "Failed to delete student!";
            }
        } catch (SQLException e) {
            result = "Database Error";
        }
        return result;
    }
    
}
