package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Student;

public class AttendanceDao {
    
    private Connection con = null;
    
    public AttendanceDao() {
        con = Dbcon.createConnection();
    }
    
    public String makeAttendance(int rno, String subName, String dateStr, String toHourTime, String fromHourTime) {
        String returnString;
        try {
            if( !this.isStudentPresent(rno) ) {
                returnString = "No record found";
                return returnString;
            }
            if( this.hasAttendanceMade(rno, subName, fromHourTime, toHourTime, dateStr) ){
                returnString = "Attendance already made!";
                return returnString;
            }
            PreparedStatement pstmt = con.prepareStatement("insert into "
                    + "attendance(rno,from_time,to_time,subject,date) values(?,?,?,?,?)");
            pstmt.setLong(1, rno);
            pstmt.setString(2, fromHourTime);
            pstmt.setString(3, toHourTime);
            pstmt.setString(4, subName);
            pstmt.setString(5, dateStr);
            int i = pstmt.executeUpdate();
            if( i==1 ) {
                returnString = "Attendance made!";
            } else {
                returnString = "Failed to make attendance!";
            }
        } catch (SQLException e) {
            returnString = "Database Error1!";
        }
        return returnString;
    }
    
    public boolean hasAttendanceMade( int rno, String subName, String fromHourTime, String toHourTime, String dateStr ){
        boolean bool = false;
        
        try {
            PreparedStatement pstmt = con.prepareStatement("select * from attendance where rno=? and subject=?"
                    + " and from_time=? and to_time=? and date=?");
            pstmt.setInt(1, rno);
            pstmt.setString(2, subName);
            pstmt.setString(3, fromHourTime);
            pstmt.setString(4, toHourTime);
            pstmt.setString(5, dateStr);
            ResultSet rst = pstmt.executeQuery();
            if(rst.next()) {
                bool = true;
            }
        } catch (SQLException e) {
            System.out.println("Database Error2!");
        }
        
        return bool;
    }
    
    public boolean isStudentPresent( int rno ) {
        boolean bool = false;
        try {
            PreparedStatement pstmt = con.prepareStatement("select * from student where rno=?");
            pstmt.setInt(1, rno);
            ResultSet rst = pstmt.executeQuery();
            if(rst.next()) {
                bool = true;
            }
        } catch (SQLException e) {
            System.out.println("Database Error3!");
        }        
        return bool;
    }

    public List<Student> getAttendance(String dateStr, String fromTimeStr, String toTimeStr, String subject) {
        List<Student> students = new ArrayList<>();
        List<Integer> rollNumbers = new ArrayList<>();
        try {
            PreparedStatement pstmt = con.prepareStatement("select rno from attendance where from_time=? and to_time=? and date=? and subject=?");
            pstmt.setString(1, fromTimeStr);
            pstmt.setString(2, toTimeStr);
            pstmt.setString(3, dateStr);
            pstmt.setString(4, subject);
            ResultSet rst = pstmt.executeQuery();
            while(rst.next()) {
                rollNumbers.add(rst.getInt("rno"));
            }
            
            for(int i=0;i<rollNumbers.size();i++) {
                PreparedStatement pstmt1 = con.prepareStatement("select * from student where rno=?");
                pstmt1.setInt(1, rollNumbers.get(i));
                ResultSet rst1 = pstmt1.executeQuery();
                if(rst1.next()){
                    students.add(new Student(
                    rst1.getInt("rno"),
                rst1.getString("fullname"),
                rst1.getString("username"),
                rst1.getString("password"),
                rst1.getString("class")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
    
}
