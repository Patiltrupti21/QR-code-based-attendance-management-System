package qrcode_reader;

import models.Teacher;

public class TeacherDashboard extends javax.swing.JFrame {

    private Teacher teacher;

    public TeacherDashboard(Teacher teacher) {
        this.teacher = teacher;
        initComponents();
        pack();
        setLocationRelativeTo(null);
        setTitle("Teacher Dashboard");
        setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        viewLecturAttndncBtn = new javax.swing.JButton();
        newAttndncBtn = new javax.swing.JButton();
        manageStudentsBtn = new javax.swing.JButton();
        logoutBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Teacher Dashboard");

        viewLecturAttndncBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        viewLecturAttndncBtn.setText("View Lecture Attendance");
        viewLecturAttndncBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewLecturAttndncBtnActionPerformed(evt);
            }
        });

        newAttndncBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        newAttndncBtn.setText("New Attendance");
        newAttndncBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newAttndncBtnActionPerformed(evt);
            }
        });

        manageStudentsBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        manageStudentsBtn.setText("Manage Students");
        manageStudentsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageStudentsBtnActionPerformed(evt);
            }
        });

        logoutBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        logoutBtn.setText("Logout");
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(53, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(logoutBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(viewLecturAttndncBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(manageStudentsBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(newAttndncBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                .addGap(41, 41, 41))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(manageStudentsBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(viewLecturAttndncBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(newAttndncBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logoutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void viewLecturAttndncBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewLecturAttndncBtnActionPerformed
        dispose();
        setVisible(false);
        new ViewLectureAttendance(teacher);
    }//GEN-LAST:event_viewLecturAttndncBtnActionPerformed

    private void newAttndncBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newAttndncBtnActionPerformed
        dispose();
        setVisible(false);
        new NewAttendance(teacher);
    }//GEN-LAST:event_newAttndncBtnActionPerformed

    private void manageStudentsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageStudentsBtnActionPerformed
        dispose();
        setVisible(false);
        new ManageStudents(teacher);
    }//GEN-LAST:event_manageStudentsBtnActionPerformed

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
        dispose();
        setVisible(false);
        new TeacherLogin();
    }//GEN-LAST:event_logoutBtnActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JButton manageStudentsBtn;
    private javax.swing.JButton newAttndncBtn;
    private javax.swing.JButton viewLecturAttndncBtn;
    // End of variables declaration//GEN-END:variables
}
