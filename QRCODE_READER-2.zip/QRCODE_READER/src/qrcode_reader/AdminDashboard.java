package qrcode_reader;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import models.Admin;
import models.Teacher;
import utils.AttendanceDao;
import utils.TeacherDao;

public class AdminDashboard extends javax.swing.JFrame {
    private Admin admin;
    
    public AdminDashboard(Admin admin) {
        this.admin = admin;
        initComponents();
        pack();
        setLocationRelativeTo(null);
        setTitle("Admin Dashboard");
        setVisible(true);
        getTeachers();
    }

    private void getTeachers(){
        TeacherDao tdao = new TeacherDao();
        List<Teacher> teachers = tdao.getTeachers();
        DefaultTableModel dtm = (DefaultTableModel) teacherTable.getModel();
        for( Teacher teacher:teachers ) {
            dtm.addRow(new Object[]{
                teacher.getId(),
                teacher.getFullname(),
                teacher.getUsername(),
                teacher.getPassword(),
                teacher.getSubject()
            });
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        teacherTable = new javax.swing.JTable();
        deleteBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        addBtn = new javax.swing.JButton();
        newBtn = new javax.swing.JButton();
        logoutBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Manage Teachers");

        teacherTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Fullname", "Username", "Password", "Subjects"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(teacherTable);

        deleteBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        updateBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        addBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        addBtn.setText("Add");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        newBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        newBtn.setText("New");
        newBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBtnActionPerformed(evt);
            }
        });

        logoutBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        logoutBtn.setText("Logout");
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 482, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(addBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(newBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(updateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(deleteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(logoutBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(21, 21, 21))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logoutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) teacherTable.getModel();
        int index = teacherTable.getSelectedRow();
        if(index<0) {
            JOptionPane.showMessageDialog(deleteBtn, "Please select a row!");
        } else {
            try {
                int id = Integer.parseInt(dtm.getValueAt(index, 0)+"");
                TeacherDao tdao = new TeacherDao();
                String result = tdao.deleteTeacher(id);
                JOptionPane.showMessageDialog(deleteBtn, result);
                dispose();
                new AdminDashboard(admin);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(deleteBtn, "Invalid ID!");
            }
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) teacherTable.getModel();
        int index = teacherTable.getSelectedRow();
        if(index<0) {
            JOptionPane.showMessageDialog(updateBtn, "Please select a row!");
        } else {
            try {
                int id = Integer.parseInt(dtm.getValueAt(index, 0)+"");
                Teacher newTeacher = new Teacher(
                    id,
                    dtm.getValueAt(index, 1)+"",
                    dtm.getValueAt(index, 2)+"",
                    dtm.getValueAt(index, 3)+"",
                    dtm.getValueAt(index, 4)+""
                );
                boolean isInvalid = false;
                if( newTeacher.getFullname().equals("") ||
                    newTeacher.getUsername().equals("") ||
                    newTeacher.getPassword().equals("") ||
                    newTeacher.getSubject().equals("")
                ) {
                    isInvalid = true;
                } 

                if(isInvalid){
                    JOptionPane.showMessageDialog(updateBtn, "Invalid fields!");
                } else {
                    TeacherDao tdao = new TeacherDao();
                    String result = tdao.updateTeacher(newTeacher);
                    JOptionPane.showMessageDialog(updateBtn, result);
                    dispose();
                    new AdminDashboard(admin);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(updateBtn, "Invalid ID!");
            }
        }
    }//GEN-LAST:event_updateBtnActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) teacherTable.getModel();
        Teacher newTeacher = new Teacher(
            dtm.getValueAt(dtm.getRowCount()-1, 1)+"",
            dtm.getValueAt(dtm.getRowCount()-1, 2)+"",
            dtm.getValueAt(dtm.getRowCount()-1, 3)+"",
            dtm.getValueAt(dtm.getRowCount()-1, 4)+""
        );
        boolean isInvalid = false;
        if( newTeacher.getFullname().equals("") ||
            newTeacher.getUsername().equals("") ||
            newTeacher.getPassword().equals("") ||
            newTeacher.getSubject().equals("")
        ) {
            isInvalid = true;
        } 
         
        if(isInvalid){
            JOptionPane.showMessageDialog(addBtn, "Invalid fields!");
        } else {
            TeacherDao tdao = new TeacherDao();
            String result = tdao.registerTeacher(newTeacher);
            JOptionPane.showMessageDialog(addBtn, result);
            dispose();
            new AdminDashboard(admin);
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void newBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) teacherTable.getModel();
        dtm.addRow(new Object[]{"","","","",""});
    }//GEN-LAST:event_newBtnActionPerformed

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
        setVisible(false);
        new AdminLogin();
    }//GEN-LAST:event_logoutBtnActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JButton newBtn;
    private javax.swing.JTable teacherTable;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
