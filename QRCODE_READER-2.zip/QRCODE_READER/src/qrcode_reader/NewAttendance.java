package qrcode_reader;

import utils.AttendanceDao;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import models.Teacher;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

public class NewAttendance extends JFrame implements Runnable,ThreadFactory {
    
    private WebcamPanel panel = null;
    private Webcam webcam = null;
    private Executor executor = Executors.newSingleThreadExecutor(this);
    private int rno = 0;
    private boolean bool = true;
    private Teacher teacher;
    private List<String> list = new ArrayList<>();
    
    public NewAttendance(Teacher teacher) {
        this.teacher = teacher;
        initComponents();
        initWebcam();
        pack();
        setLocationRelativeTo(null);
        setTitle("Show QR Code");
        setVisible(true);
        extractSubjects();
    }
    
    public NewAttendance(Teacher teacher, LocalTime fromTime, LocalTime toTime, int index){
        this.teacher = teacher;
        initComponents();
        initWebcam();
        pack();
        setLocationRelativeTo(null);
        setTitle("Show QR Code");
        setVisible(true);
        extractSubjects();
        fromTimePicker.setTime(fromTime);
        toTimePicker.setTime(toTime);
        subjectSelector.setSelectedIndex(index);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        fromTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        jLabel3 = new javax.swing.JLabel();
        toTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        subjectSelector = new javax.swing.JComboBox<>();
        dashBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 420, 230));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("From Time");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));
        jPanel1.add(fromTimePicker, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 270, 110, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("To Time");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 280, -1, -1));
        jPanel1.add(toTimePicker, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 270, 110, 30));

        jPanel1.add(subjectSelector, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, 420, 30));

        dashBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        dashBtn.setText("Go Back to Dashboard");
        dashBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashBtnActionPerformed(evt);
            }
        });
        jPanel1.add(dashBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 420, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 498, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dashBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashBtnActionPerformed
        setVisible(false);
        new TeacherDashboard(teacher);
    }//GEN-LAST:event_dashBtnActionPerformed
    
    private void initWebcam() {
        Dimension size = WebcamResolution.QVGA.getSize();
        webcam = Webcam.getWebcams().get(0);
        webcam.setViewSize(size);
        
        panel = new WebcamPanel(webcam);
        panel.setPreferredSize(size);
        panel.setFPSDisplayed(true);
        
        jPanel2.add(panel, new AbsoluteConstraints(0,0,470,300));
        
        executor.execute(this);
    }
    
    private void extractSubjects(){
        String subjects = teacher.getSubject();
        String subject = "";
        for(int i=0;i<subjects.length();i++) {
            if(subjects.charAt(i)==',') {
                list.add(subject);
                subject = "";
            } else if( i==subjects.length()-1 ){
                subject += subjects.charAt(i);
                list.add(subject);
                subject = "";
            } else {
                subject += subjects.charAt(i);
            }
        }
        for (String sub : list) {
            subjectSelector.addItem(sub);
        }
    }
    
    private void markAttendance(){
        String subName = subjectSelector.getSelectedItem()+"";
        String fromHourTime;
        String toHourTime;
        long fromTime;
        long toTime;
        String dateStr;
        AttendanceDao dao = new AttendanceDao();
        
        try {
            fromHourTime = fromTimePicker.getTime().toString();
            toHourTime = toTimePicker.getTime().toString();
            fromTime = fromTimePicker.getTime().toNanoOfDay();
            toTime = toTimePicker.getTime().toNanoOfDay();
            Date date = new Date();
            LocalDate d = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            dateStr = d.toString();
            
            if( toTime<=fromTime ) {
                JOptionPane.showMessageDialog(rootPane, "To time should be greater than from time");
            } else {
                String result = dao.makeAttendance(rno, subName, dateStr, toHourTime, fromHourTime);
                webcam.close();
                dispose();
                bool = false;
                JOptionPane.showMessageDialog( this, result);
                new NewAttendance(teacher,fromTimePicker.getTime(),toTimePicker.getTime(),subjectSelector.getSelectedIndex());
            }
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(rootPane, "Please select all fields");
        }
    }
    
    @Override
    public void run(){
        while(bool){
            try {
                Thread.sleep(100);
            }catch  (InterruptedException ex) {
//                Logger.getLogger(NewAttendance.class.getName()).log(Level.SEVERE,null, ex);
            }

            Result result = null;
            BufferedImage image = null;

            if(webcam.isOpen()){
                if((image = webcam.getImage()) == null) {
                    continue;
                }
            }

            LuminanceSource source=null;
            BinaryBitmap bitmap=null;
            try {
                source = new BufferedImageLuminanceSource(image);
                bitmap = new BinaryBitmap(new HybridBinarizer(source));
            } catch (Exception e) {
            }

            try {
                if(bitmap!=null && source!=null) {
                    result = new MultiFormatReader().decode(bitmap);
                }
            } catch (NotFoundException ex) {
//                Logger.getLogger(NewAttendance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            
            if(result!=null){
                try {
                    String rnoString = result.getText();
                    rno = Integer.parseInt(rnoString);
                    result = null;
                    if(bool) markAttendance();
                } catch (NumberFormatException | StringIndexOutOfBoundsException e) {
                    bool = false;
                    webcam.close();
                    dispose();
                    JOptionPane.showMessageDialog( null, "Invalid Barcode!");
                    new NewAttendance(teacher).setVisible(true);
                }
            }
        };

    }
     
    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, "My Thread");
        t.setDaemon(true);
        return t;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dashBtn;
    private com.github.lgooddatepicker.components.TimePicker fromTimePicker;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> subjectSelector;
    private com.github.lgooddatepicker.components.TimePicker toTimePicker;
    // End of variables declaration//GEN-END:variables
}
