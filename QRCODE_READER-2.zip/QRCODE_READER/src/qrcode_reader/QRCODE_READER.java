package qrcode_reader;

public class QRCODE_READER {

    public static void main(String[] args) {
        new AdminLogin().setVisible(true);
    }
    
}
