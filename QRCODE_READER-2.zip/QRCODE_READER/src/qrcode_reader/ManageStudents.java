package qrcode_reader;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import models.Student;
import models.Teacher;
import utils.StudentDao;

public class ManageStudents extends javax.swing.JFrame {
    private Teacher teacher;
    
    public ManageStudents(Teacher teacher) {
        this.teacher = teacher;
        initComponents();
        pack();
        setLocationRelativeTo(null);
        setTitle("Teacher Dashboard");
        setVisible(true);
        getStudents();
    }

    private void getStudents(){
        StudentDao sdao = new StudentDao();
        List<Student> students = sdao.getStudents();
        DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
        for( Student student:students ) {
            dtm.addRow(new Object[]{
                student.getRno(),
                student.getFullname(),
                student.getUsername(),
                student.getPassword(),
                student.getClassName()
            });
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        deleteBtn = new javax.swing.JButton();
        updateBtn = new javax.swing.JButton();
        addBtn = new javax.swing.JButton();
        newBtn = new javax.swing.JButton();
        dashBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Manage Students");

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Roll No", "Fullname", "Username", "Password", "Class"
            }
        ));
        jScrollPane1.setViewportView(studentTable);

        deleteBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        updateBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        addBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        addBtn.setText("Add");
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        newBtn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        newBtn.setText("New");
        newBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newBtnActionPerformed(evt);
            }
        });

        dashBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        dashBtn.setText("Go Back to Dashboard");
        dashBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 482, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(addBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(newBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(updateBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(deleteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(dashBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(21, 21, 21))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dashBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
        int index = studentTable.getSelectedRow();
        if(index<0) {
            JOptionPane.showMessageDialog(deleteBtn, "Please select a row!");
        } else {
            try {
                int rno = Integer.parseInt(dtm.getValueAt(index, 0)+"");
                StudentDao sdao = new StudentDao();
                String result = sdao.deleteStudent(rno);
                JOptionPane.showMessageDialog(deleteBtn, result);
                dispose();
                new ManageStudents(teacher);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(deleteBtn, "Invalid Roll No!");
            }
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
        int index = studentTable.getSelectedRow();
        if(index<0) {
            JOptionPane.showMessageDialog(updateBtn, "Please select a row!");
        } else {
            try {
                int rno = Integer.parseInt(dtm.getValueAt(index, 0)+"");
                Student newStudent = new Student(
                    rno,
                    dtm.getValueAt(index, 1)+"",
                    dtm.getValueAt(index, 2)+"",
                    dtm.getValueAt(index, 3)+"",
                    dtm.getValueAt(index, 4)+""
                );
                boolean isInvalid = false;
                if( newStudent.getFullname().equals("") ||
                    newStudent.getUsername().equals("") ||
                    newStudent.getPassword().equals("") ||
                    newStudent.getClassName().equals("")
                ) {
                    isInvalid = true;
                } 

                if(isInvalid){
                    JOptionPane.showMessageDialog(updateBtn, "Invalid fields!");
                } else {
                    StudentDao sdao = new StudentDao();
                    String result = sdao.updateStudent(newStudent);
                    JOptionPane.showMessageDialog(updateBtn, result);
                    dispose();
                    new ManageStudents(teacher);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(updateBtn, "Invalid Roll No!");
            }
        }
    }//GEN-LAST:event_updateBtnActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
        Student newStudent = new Student(
            dtm.getValueAt(dtm.getRowCount()-1, 1)+"",
            dtm.getValueAt(dtm.getRowCount()-1, 2)+"",
            dtm.getValueAt(dtm.getRowCount()-1, 3)+"",
            dtm.getValueAt(dtm.getRowCount()-1, 4)+""
        );
        boolean isInvalid = false;
        if( newStudent.getFullname().equals("") ||
            newStudent.getUsername().equals("") ||
            newStudent.getPassword().equals("") ||
            newStudent.getClassName().equals("")
        ) {
            isInvalid = true;
        } 
         
        if(isInvalid){
            JOptionPane.showMessageDialog(addBtn, "Invalid fields!");
        } else {
            StudentDao sdao = new StudentDao();
            String result = sdao.registerStudent(newStudent);
            JOptionPane.showMessageDialog(addBtn, result);
            dispose();
            new ManageStudents(teacher);
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void newBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newBtnActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
        dtm.addRow(new Object[]{"","","","",""});
    }//GEN-LAST:event_newBtnActionPerformed

    private void dashBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashBtnActionPerformed
        setVisible(false);
        new TeacherDashboard(teacher);
    }//GEN-LAST:event_dashBtnActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addBtn;
    private javax.swing.JButton dashBtn;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton newBtn;
    private javax.swing.JTable studentTable;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
