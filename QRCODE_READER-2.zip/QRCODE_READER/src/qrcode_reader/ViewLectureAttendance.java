package qrcode_reader;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import models.Student;
import models.Teacher;
import utils.AttendanceDao;

public class ViewLectureAttendance extends javax.swing.JFrame {

    private Teacher teacher;
    private List<String> list = new ArrayList<>();
    
    public ViewLectureAttendance( Teacher teacher ) {
        this.teacher = teacher;
        initComponents();
        pack();
        setLocationRelativeTo(null);
        setTitle("Lecture Attendance");
        setVisible(true);
        extractSubjects();
    }
    
    private void extractSubjects(){
        String subjects = teacher.getSubject();
        String subject = "";
        for(int i=0;i<subjects.length();i++) {
            if(subjects.charAt(i)==',') {
                list.add(subject);
                subject = "";
            } else if( i==subjects.length()-1 ){
                subject += subjects.charAt(i);
                list.add(subject);
                subject = "";
            } else {
                subject += subjects.charAt(i);
            }
        }
        for (String sub : list) {
            subjectSelector.addItem(sub);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        fromTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        toTimePicker = new com.github.lgooddatepicker.components.TimePicker();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        datePicker = new com.github.lgooddatepicker.components.DatePicker();
        dashBtn = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        subjectSelector = new javax.swing.JComboBox<>();
        displayAttendanceBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Roll_no", "Fullname", "Username", "Class"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(studentTable);

        jLabel3.setText("Date");
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jLabel4.setText("Lecture Attendance of Class");
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N

        jLabel5.setText("From Time");
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jLabel6.setText("To Time");
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        dashBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        dashBtn.setText("Go Back to Dashboard");
        dashBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashBtnActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Subject");

        displayAttendanceBtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        displayAttendanceBtn.setText("Display Attendance");
        displayAttendanceBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayAttendanceBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(46, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addComponent(jLabel4))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(dashBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 583, Short.MAX_VALUE)
                        .addComponent(displayAttendanceBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(27, 43, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(datePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(subjectSelector, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(toTimePicker, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(fromTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(80, 80, 80))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel4)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(datePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fromTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(toTimePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(subjectSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(displayAttendanceBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(dashBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dashBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashBtnActionPerformed
        dispose();
        setVisible(false);
        new TeacherDashboard(teacher);
    }//GEN-LAST:event_dashBtnActionPerformed

    public static void main(String[] args) {
        new ViewLectureAttendance(new Teacher(0,"","","",""));
    }
    
    private void displayAttendanceBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayAttendanceBtnActionPerformed
        // Fetch Input
        String dateStr = datePicker.toString();
        String fromTimeStr = fromTimePicker.toString();
        String toTimeStr = toTimePicker.toString();
        String subject = subjectSelector.getSelectedItem().toString();
        boolean isInvalid=false;
        
        // Validate Input
        try {
            LocalDate selectedLocalDate = datePicker.getDate();
            Date selectedDate = Date.from(selectedLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
            Date currDate = new Date();
            if( dateStr.equals("") || selectedDate.getTime()>currDate.getTime() ) {
                JOptionPane.showMessageDialog(displayAttendanceBtn, "Invalid date");
                isInvalid = true;
            }
            if(fromTimeStr.equals("") || toTimeStr.equals("")) {
                JOptionPane.showMessageDialog(displayAttendanceBtn, "Invalid lecture timings");
                isInvalid = true;
            }
            long fromTime = fromTimePicker.getTime().toNanoOfDay();
            long toTime = toTimePicker.getTime().toNanoOfDay();
            if( toTime<=fromTime ) {
                JOptionPane.showMessageDialog(rootPane, "To time should be greater than from time");
                isInvalid = true;
            }
            
            // Get Output
            if( !isInvalid ) {
                AttendanceDao adao = new AttendanceDao();
                List<Student> students = adao.getAttendance(dateStr,fromTimeStr,toTimeStr,subject);
                DefaultTableModel dtm = (DefaultTableModel) studentTable.getModel();
                for( Student student:students ) {
                    dtm.addRow(new Object[]{
                        student.getRno(),
                        student.getFullname(),
                        student.getUsername(),
                        student.getClassName()
                    });
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(displayAttendanceBtn, "Invalid fields");
        }
        
    }//GEN-LAST:event_displayAttendanceBtnActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton dashBtn;
    private com.github.lgooddatepicker.components.DatePicker datePicker;
    private javax.swing.JButton displayAttendanceBtn;
    private com.github.lgooddatepicker.components.TimePicker fromTimePicker;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable studentTable;
    private javax.swing.JComboBox<String> subjectSelector;
    private com.github.lgooddatepicker.components.TimePicker toTimePicker;
    // End of variables declaration//GEN-END:variables
}
